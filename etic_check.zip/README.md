ETIC CHECK:

Plateforme checkin le club ETIC.
